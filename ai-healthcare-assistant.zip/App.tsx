import React,
{
  useState,
  useCallback
}
from 'react';
import type {
  Message
}
from './types';
import {
  ChatWindow
}
from './components/ChatWindow';
import {
  MessageInput
}
from './components/MessageInput';
import {
  getBotResponse,
  chatSession,
  generateImageForCondition,
  generateVideoForCondition
}
from './services/geminiService';
import type {
  Chat
}
from '@google/genai';
import {
  QuickReplies
}
from './components/QuickReplies';

// @ts-ignore
const aistudio = window.aistudio;

function App() {
  const [messages, setMessages] = useState < Message[] > ([
    {
      id: 1,
      text: "Hello there! 👋 I’m *Dr. HealthBot*, your friendly digital health companion. I’m here to keep you healthy, happy, and informed. 💙 How are you feeling today?",
      sender: 'bot'
    }
  ]);
  const [userInput, setUserInput] = useState('');
  const [isLoading, setIsLoading] = useState(false);
  const [chat] = useState < Chat > (chatSession);

  const handleSendMessage = useCallback(async (prompt ? : string) => {
    const trimmedInput = (prompt || userInput).trim();
    if (!trimmedInput || isLoading) return;

    const userMessage: Message = {
      id: Date.now(),
      text: trimmedInput,
      sender: 'user',
    };

    setMessages((prev) => [...prev, userMessage]);
    setUserInput('');
    setIsLoading(true);

    try {
      const {
        text: botResponseText,
        functionCall
      } = await getBotResponse(chat, trimmedInput);
      const botMessage: Message = {
        id: Date.now() + 1,
        text: botResponseText,
        sender: 'bot',
        visualTriggerCondition: functionCall?.args?.condition,
      };
      setMessages((prev) => [...prev, botMessage]);
    } catch (error) {
      const errorMessage: Message = {
        id: Date.now() + 1,
        text: "I'm sorry, something went wrong. Please try again.",
        sender: 'bot',
      };
      setMessages((prev) => [...prev, errorMessage]);
    } finally {
      setIsLoading(false);
    }
  }, [userInput, isLoading, chat]);

  const handleGenerateImage = async (condition: string, messageId: number) => {
    setMessages(prev => prev.map(m => m.id === messageId ? { ...m,
      visualLoading: 'image',
      visualTriggerCondition: undefined
    } : m));

    try {
      const imageUrl = await generateImageForCondition(condition);
      setMessages(prev => prev.map(m => m.id === messageId ? { ...m,
        visualLoading: false,
        imageUrl
      } : m));
    } catch (error) {
      const text = error instanceof Error ? error.message : "Failed to generate image.";
      setMessages(prev => prev.map(m => m.id === messageId ? { ...m,
        visualLoading: false,
        text: m.text + `\n\n**Error:** ${text}`
      } : m));
    }
  };

  const handleGenerateVideo = async (condition: string, messageId: number) => {
      try {
          if (aistudio) {
              const hasKey = await aistudio.hasSelectedApiKey();
              if (!hasKey) {
                  alert("To generate videos, you must select a project with the Veo API enabled. Please select a project to continue.\n\nFor more information on billing, visit: ai.google.dev/gemini-api/docs/billing");
                  await aistudio.openSelectKey();
              }
          }

          setMessages(prev => prev.map(m => m.id === messageId ? { ...m,
              visualLoading: 'video',
              visualTriggerCondition: undefined
          } : m));

          const videoUrl = await generateVideoForCondition(condition);
          setMessages(prev => prev.map(m => m.id === messageId ? { ...m,
              visualLoading: false,
              videoUrl
          } : m));

      } catch (error) {
          const text = error instanceof Error ? error.message : "Failed to generate video.";
          setMessages(prev => prev.map(m => m.id === messageId ? { ...m,
              visualLoading: false,
              text: m.text + `\n\n**Error:** ${text}`
          } : m));
          if (aistudio && text.includes("Invalid API Key")) {
// Fix: Re-open the API key selection dialog if the current key is invalid, instead of calling a non-existent `clearCache` method.
               await aistudio.openSelectKey();
          }
      }
  };


  return ( 
    <div className = "flex flex-col h-screen font-sans" >
        <header className = "bg-white/80 backdrop-blur-sm shadow-md p-4 border-b border-gray-200/80" >
            <div className = "max-w-4xl mx-auto" >
                <h1 className = "text-2xl font-bold text-[#52b69a] text-center" >
                    Dr.HealthBot < span role = "img"
                    aria-label = "Stethoscope"
                    className = "inline-block animate-pulse" > 🩺 </span> 
                </h1> 
                <p className = "text-center text-sm text-gray-600 italic mt-1" > Your Virtual Health Companion </p> 
            </div> 
        </header>

        <main className = "flex-1 flex flex-col max-w-4xl w-full mx-auto" >
            <div className = "flex-1 flex flex-col bg-white/70 backdrop-blur-sm shadow-lg rounded-t-lg mt-4 overflow-hidden" >
                <ChatWindow 
                    messages={messages} 
                    isLoading={isLoading} 
                    onSendMessage={handleSendMessage}
                    onGenerateImage={handleGenerateImage}
                    onGenerateVideo={handleGenerateVideo}
                /> 
                <QuickReplies onQuickReply = {handleSendMessage} isLoading = {isLoading} /> 
                <MessageInput
                    userInput = {userInput}
                    setUserInput = {setUserInput}
                    onSendMessage = {() => handleSendMessage()}
                    isLoading = {isLoading}
                /> 
            </div> 
        </main>

        <footer className = "text-center p-4 text-xs text-gray-700" >
            <p className = 'font-semibold' > 💙Dr.HealthBot — Here to keep you healthy, happy, and informed! </p> 
            <p className = "mt-1" > ⚠️ This chatbot provides general health advice and home remedies only. Please consult a doctor for medical diagnosis or treatment. </p> 
        </footer> 
    </div>
  );
}

export default App;