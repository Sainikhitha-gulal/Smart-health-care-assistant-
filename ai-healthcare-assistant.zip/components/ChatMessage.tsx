import React from 'react';
import type { Message } from '../types';
import { marked } from 'marked';

interface ChatMessageProps {
  message: Message;
  isLoading: boolean;
  onSendMessage: (prompt: string) => void;
  onGenerateImage: (condition: string, messageId: number) => void;
  onGenerateVideo: (condition: string, messageId: number) => void;
}

const VisualLoadingIndicator: React.FC<{type: 'image' | 'video'}> = ({type}) => (
    <div className="mt-3 p-3 bg-gray-100 rounded-lg text-center text-sm text-gray-600">
        <div className="flex items-center justify-center">
            <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-[#52b69a]" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
            </svg>
            Generating {type}...
        </div>
        {type === 'video' && <p className="text-xs mt-1">This can take a minute or two.</p>}
    </div>
);


export const ChatMessage: React.FC<ChatMessageProps> = ({ message, onSendMessage, onGenerateImage, onGenerateVideo }) => {
  const isBot = message.sender === 'bot';
  const sanitizedHtml = isBot ? marked.parse(message.text, { gfm: true, breaks: true }) : message.text;

  // Don't show follow-up on the very first greeting message
  const showFollowUpButtons = isBot && message.id !== 1 && !message.visualTriggerCondition && !message.imageUrl && !message.videoUrl;

  return (
    <div className={`flex flex-col my-4 ${isBot ? 'items-start' : 'items-end'}`}>
      <div className={`flex items-end gap-3 ${!isBot && 'flex-row-reverse'}`}>
        <div className={`flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center text-2xl shadow-sm ${
            isBot ? 'bg-[#cfe9f5] border-2 border-white' : 'bg-[#d8f3dc] border-2 border-white'
        }`}>
          {isBot ? '🩺' : '🙂'}
        </div>
        <div
          className={`relative max-w-md lg:max-w-2xl px-5 py-3 shadow-lg ${
            isBot
              ? 'bg-[#d0f0f0] text-gray-800 border border-teal-200 rounded-tr-3xl rounded-br-3xl rounded-bl-3xl rounded-tl-xl'
              : 'bg-white text-[#003049] border border-green-200 rounded-tl-3xl rounded-bl-3xl rounded-br-3xl rounded-tr-xl'
          }`}
        >
          {isBot ? (
              <div className="prose prose-sm max-w-none" dangerouslySetInnerHTML={{ __html: sanitizedHtml as string }} />
          ) : (
              <p>{message.text}</p>
          )}

          {message.imageUrl && <img src={message.imageUrl} alt="Generated visual aid" className="mt-3 rounded-lg shadow-md" />}
          {message.videoUrl && <video src={message.videoUrl} controls autoPlay muted loop className="mt-3 rounded-lg shadow-md w-full" />}
          {message.visualLoading && <VisualLoadingIndicator type={message.visualLoading}/>}
        </div>
      </div>
      
      <div className="mt-3 flex flex-wrap gap-2" style={{ paddingLeft: isBot ? '3.25rem' : '0', paddingRight: !isBot ? '3.25rem' : '0' }}>
        {showFollowUpButtons && (
            <>
                <button
                    onClick={() => onSendMessage('Check another symptom')}
                    disabled={!!message.visualLoading}
                    className="px-3 py-1 text-xs font-semibold text-[#52b69a] bg-white border border-[#a8dadc] rounded-full hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                >
                    Check another symptom
                </button>
                <button
                    onClick={() => onSendMessage('View health tips')}
                    disabled={!!message.visualLoading}
                    className="px-3 py-1 text-xs font-semibold text-[#52b69a] bg-white border border-[#a8dadc] rounded-full hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                >
                    View health tips
                </button>
            </>
        )}
        {message.visualTriggerCondition && (
            <>
                <button
                    onClick={() => onGenerateImage(message.visualTriggerCondition!, message.id)}
                    disabled={!!message.visualLoading}
                    className="px-3 py-1 text-xs font-semibold text-[#52b69a] bg-white border border-[#a8dadc] rounded-full hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                >
                    Generate Image ✨
                </button>
                <button
                    onClick={() => onGenerateVideo(message.visualTriggerCondition!, message.id)}
                    disabled={!!message.visualLoading}
                    className="px-3 py-1 text-xs font-semibold text-[#52b69a] bg-white border border-[#a8dadc] rounded-full hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed transition-all"
                >
                    Generate Video 🎥
                </button>
            </>
        )}
      </div>
    </div>
  );
};