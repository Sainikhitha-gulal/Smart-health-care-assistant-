
import React, { useRef, useEffect } from 'react';
import type { Message } from '../types';
import { ChatMessage } from './ChatMessage';

interface ChatWindowProps {
  messages: Message[];
  isLoading: boolean;
  onSendMessage: (prompt: string) => void;
  onGenerateImage: (condition: string, messageId: number) => void;
  onGenerateVideo: (condition: string, messageId: number) => void;
}

const TypingIndicator: React.FC = () => (
    <div className="flex items-end justify-start gap-3 my-4">
        <div className="flex-shrink-0 w-10 h-10 rounded-full flex items-center justify-center text-2xl shadow-sm bg-[#cfe9f5] border-2 border-white">
           🩺
        </div>
        <div className="relative px-5 py-3 shadow-lg bg-[#d0f0f0] border border-teal-200 rounded-tr-[2rem] rounded-tl-[2rem] rounded-br-[2rem]">
            <div className="flex items-center justify-center space-x-1">
                <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                <div className="w-2 h-2 bg-gray-500 rounded-full animate-bounce"></div>
            </div>
        </div>
    </div>
);


export const ChatWindow: React.FC<ChatWindowProps> = ({ messages, isLoading, onSendMessage, onGenerateImage, onGenerateVideo }) => {
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages, isLoading]);

  return (
    <div className="flex-1 p-4 sm:p-6 overflow-y-auto">
      {messages.map((msg) => (
        <ChatMessage 
          key={msg.id} 
          message={msg} 
          isLoading={isLoading} 
          onSendMessage={onSendMessage}
          onGenerateImage={onGenerateImage}
          onGenerateVideo={onGenerateVideo}
        />
      ))}
      {isLoading && <TypingIndicator />}
      <div ref={messagesEndRef} />
    </div>
  );
};
