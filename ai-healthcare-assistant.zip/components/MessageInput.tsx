
import React from 'react';
import { SendIcon } from './icons';

interface MessageInputProps {
  userInput: string;
  setUserInput: (value: string) => void;
  onSendMessage: () => void;
  isLoading: boolean;
}

export const MessageInput: React.FC<MessageInputProps> = ({ userInput, setUserInput, onSendMessage, isLoading }) => {
  const handleKeyDown = (event: React.KeyboardEvent<HTMLInputElement>) => {
    if (event.key === 'Enter') {
      onSendMessage();
    }
  };

  return (
    <div className="p-4 pt-2 sm:p-6 sm:pt-4 bg-transparent">
      <div className="relative flex">
        <input
          type="text"
          placeholder="Ask about symptoms or for a health tip..."
          className="w-full pl-4 pr-12 py-3 border rounded-full bg-gray-100 text-gray-800 focus:outline-none focus:ring-2 focus:ring-[#52b69a] transition-shadow"
          value={userInput}
          onChange={(e) => setUserInput(e.target.value)}
          onKeyDown={handleKeyDown}
          disabled={isLoading}
        />
        <button
          onClick={onSendMessage}
          disabled={isLoading || !userInput.trim()}
          className="absolute right-2 top-1/2 -translate-y-1/2 p-2.5 rounded-full text-white bg-[#52b69a] hover:bg-[#45a28a] disabled:bg-gray-400 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#52b69a] transition-all duration-200"
        >
          <SendIcon />
        </button>
      </div>
    </div>
  );
};