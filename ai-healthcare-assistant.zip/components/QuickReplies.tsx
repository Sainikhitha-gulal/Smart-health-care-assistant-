import React from 'react';

interface QuickReply {
  label: string;
  emoji: string;
  value: string;
}

const quickReplies: QuickReply[] = [
  { label: 'Cold', emoji: '🤧', value: 'I have a cold' },
  { label: 'Fever', emoji: '🤒', value: 'I have fever symptoms' },
  { label: 'Cough', emoji: '😷', value: 'I have a cough or throat pain' },
  { label: 'BP', emoji: '💓', value: 'I have a question about Blood Pressure' },
  { label: 'Pulse Rate', emoji: '💗', value: 'I have a question about my Pulse Rate' },
  { label: 'Body Weight', emoji: '⚖️', value: 'I have questions about body weight' },
  { label: 'Health Tips', emoji: '💬', value: 'Give me some health tips' }
];

interface QuickRepliesProps {
  onQuickReply: (reply: string) => void;
  isLoading: boolean;
}

export const QuickReplies: React.FC<QuickRepliesProps> = ({ onQuickReply, isLoading }) => {
  return (
    <div className="px-4 sm:px-6 pt-3 pb-2 bg-transparent border-t border-gray-200/50">
      <div className="flex flex-wrap items-center justify-center gap-2">
        {quickReplies.map((reply) => (
          <button
            key={reply.label}
            onClick={() => onQuickReply(reply.value)}
            disabled={isLoading}
            className="px-4 py-2 text-sm font-bold text-white bg-[#a8dadc] rounded-full hover:bg-[#74c69d] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-[#52b69a] disabled:opacity-50 disabled:cursor-not-allowed transition-all duration-200"
            aria-label={`Ask about ${reply.label}`}
          >
            <span role="img" aria-hidden="true" className="mr-1.5">{reply.emoji}</span>
            {reply.label}
          </button>
        ))}
      </div>
    </div>
  );
};