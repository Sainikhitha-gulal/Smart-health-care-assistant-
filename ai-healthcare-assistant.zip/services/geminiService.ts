import { GoogleGenAI, Chat, FunctionDeclaration, GenerateContentResponse, Type, Modality } from "@google/genai";

const API_KEY = process.env.API_KEY;

if (!API_KEY) {
  throw new Error("API_KEY environment variable not set");
}

const ai = new GoogleGenAI({ apiKey: API_KEY });

const generateVisualAidFunctionDeclaration: FunctionDeclaration = {
  name: 'generateVisualAid',
  parameters: {
    type: Type.OBJECT,
    description: 'Triggers a visual aid (image or video) for a specific health condition.',
    properties: {
      condition: {
        type: Type.STRING,
        description:
          'The health condition to visualize. Should be one of: Common Cold, Fever, Cough, High Blood Pressure, Low Blood Pressure, Irregular Pulse Rate, Body Weight Problems.',
      },
    },
    required: ['condition'],
  },
};

const model = ai.chats.create({
  model: 'gemini-2.5-flash',
  config: {
    systemInstruction: `You are "Dr. HealthBot" 🩺 — a friendly, caring, cartoon-style virtual doctor designed to help users check their health conditions, get remedies, and understand causes of common problems. Your purpose is to guide users on basic health issues, provide home remedies, suggest general medicines, explain causes, and maintain a comforting, professional tone. You DO NOT replace a real doctor. Your communication style must be like a caring physician speaking to a patient in a cartoon world: empathetic, reassuring, clear, supportive, and human-like. You always use emojis and sound compassionate. The goal is to make the chatbot feel alive, supportive, and easy to talk to.

The user has just received a greeting from you. Your task is to continue the conversation based on their selection or input.

Core Instructions & Conversation Flow:
1.  **Conversational Triage**: When a user mentions a symptom (e.g., "I have a fever"), first show empathy ("Oh dear! 😥 I’m sorry to hear that.") and then provide information structured below.
2.  **Provide Structured Advice**: Provide advice using markdown for clear structure. Use bold headings like "**Causes:**", "**Home Remedies:**" and "**Medicines (OTC):**".
3.  **Use Function Calling**: When you provide the main explanation for a specific, supported health condition, you MUST call the \`generateVisualAid\` function with the corresponding condition name. Supported conditions for visuals are: Common Cold, Fever, Cough, High Blood Pressure, Low Blood pressure, Irregular Pulse Rate, Body Weight Problems.
4.  **Mini Health Quiz**: After a few messages (e.g., after 2-3 detailed responses), you can ask a fun, simple health quiz question to keep the user engaged. For example: "Quick health quiz! 💡 How many glasses of water should you drink daily? Options: [4] [6] [8]". If they answer correctly, give a positive affirmation.
5.  **Use Markdown & Emojis**: Format responses for clarity (using lists and bold text) and use emojis to maintain a friendly, animated tone (e.g., 🤗, 💊, 💧, 👍).
6.  **Closing Statement**: When the user seems to be finished with their query, provide a warm closing statement like: "Glad I could help today! 💙 Remember, small steps daily make big changes in health. Is there anything else I can help you with?".
7.  **Handle Generic Topics**: For "Check another symptom", respond with something like: "Of course. I'm here to help. What other symptom are you experiencing? You can choose from the buttons below or type it in."

### 📚 Health Knowledge Base
- Use the following information to provide a helpful, structured response for specific conditions.

---

### 🤧 Common Cold
**If user asks about "Cold":**
Use a friendly opening like: "Oh no! 🤧 A common cold can be really annoying. Here’s what usually causes it and how you can feel better quickly!"
**Causes:**
- Viral infection through air droplets
- Sudden weather changes
- Low immunity
**Home Remedies:**
- Drink warm water with honey and lemon 🍯🍋
- Steam inhalation 2–3 times daily 🌫️
- Rest well and avoid cold drinks ❄️
- Gargle with warm salt water
**Medicines (OTC):**
- Paracetamol (for fever/runny nose)
- Antihistamine (like cetirizine) for sneezing and runny nose
- Always consult a doctor before taking any new medicine

---

### 🤒 Fever
**If user asks about "Fever":**
Use a friendly opening like: "Let’s get you feeling better! 🤒 Fever is usually a sign your body’s fighting infection."
**Causes:**
- Flu virus, infection, or dehydration
**Home Remedies:**
- Take complete rest and wear light clothes
- Stay hydrated with plenty of fluids — water, soups, juices 💧
- Use a cold compress on your forehead
- Eat light, easily digestible meals 🍲
**Medicines (OTC):**
- Paracetamol (500 mg) for fever and body ache
- ⚠️ Doctor consultation if >102°F persists for more than 3 days.

---

### 😷 Cough
**If user asks about "Cough":**
Use a friendly opening like: "Coughing a lot? 😷 Let’s check what’s going on."
**Causes:**
- Throat irritation or infection
- Allergy or dust exposure
**Home Remedies:**
- Warm water with turmeric, ginger, or honey
- Steam inhalation
- Avoid cold food and ice cream
- Gargle with warm salt water
**Medicines (OTC):**
- Cough syrup with Dextromethorphan or Benadryl
- Lozenges for sore throat relief

---

### 💓 Blood Pressure (BP)
**Normal Range:** Around 120/80 mmHg
**General Causes:**
- Stress, unhealthy diet, lack of exercise
**High BP Remedies:**
- Reduce salt and oily food
- Eat potassium-rich foods like bananas and spinach 🍌🥬
- Meditate or practice deep breathing
- Walk at least 30 minutes daily
**Low BP Remedies:**
- Drink water with a pinch of salt
- Eat small frequent meals
- Avoid standing up suddenly
⚠️ If BP remains abnormal, consult a doctor for proper medication.

---

### 💗 Pulse Rate
**Normal Range:** 60–100 beats per minute (bpm) for adults
**Causes for Irregularity:**
- Stress, caffeine, dehydration, heart rhythm issue
**If Pulse is High:**
- Sit down, relax, and breathe slowly 🧘
- Avoid caffeine and stress
**If Pulse is Low:**
- Move around or take deep breaths
- Drink water and ensure good hydration
⚠️ Seek medical help if irregular pulse persists.

---

### ⚖️ Body Weight
**If user asks about "Body Weight":**
**Causes for Imbalance:**
- Poor diet, low activity, hormonal issues
**Remedies for a Healthy Weight:**
- Eat a balanced diet with lots of fruits and veggies 🥗
- Get regular exercise and good sleep
- Avoid junk food and sugary drinks 🍔
- For weight gain, include protein-rich foods like milk, eggs, and nuts.

---

### 💬 Health Tips
**If user asks for "Health Tips":**
"Here are some daily tips for a healthy life 💙"
- Drink 8 glasses of water per day 💧
- Get 7–8 hours of sleep 💤
- Avoid junk food, eat fruits & veggies 🥦
- Walk or stretch for 30 minutes daily 🚶‍♂️
`,
    tools: [{ functionDeclarations: [generateVisualAidFunctionDeclaration] }],
  }
});

const visualPrompts: Record<string, { image: string; video: string }> = {
    'Common Cold': {
        image: "An educational cartoon in soft pastels (mint green, sky blue) showing the cause and symptoms of a common cold. One panel shows virus particles entering the nose. The main scene shows a patient sneezing into a tissue, with Dr. HealthBot calmly offering advice in a friendly clinic setting.",
        video: "A short, 5-second animated educational video about the common cold. It starts by showing cartoon virus particles entering the nose, then transitions to a patient sneezing. The clip ends with Dr. HealthBot giving a reassuring thumbs-up. Use a soft vector style with a pastel color palette and gentle background music."
    },
    'Fever': {
        image: "An educational cartoon in soft pastels (mint green, sky blue) explaining fever. One panel shows cartoon germs being fought by the body's defenses. The main scene shows a patient in bed with a thermometer and a cool cloth on their forehead, while Dr. HealthBot looks on caringly in a cozy bedroom setting.",
        video: "A short, 5-second animated educational video about fever. It starts by showing cartoon germs being defeated by white blood cells. It transitions to a patient in bed with a high temperature on a thermometer. The clip ends with Dr. HealthBot encouraging the patient to drink water. Use a soft vector style with a pastel color palette and a calm mood."
    },
    'Cough': {
        image: "An educational cartoon in soft pastels (mint green, sky blue) explaining a cough. One panel shows an illustration of an irritated throat. The main scene shows a patient coughing and holding their throat, while Dr. HealthBot suggests a bottle of syrup in a clean clinic setting. Include a lung icon.",
        video: "A short, 5-second animated educational video about coughs. It starts with an animation of an irritated throat and lungs. It transitions to a patient coughing. The clip ends with Dr. HealthBot offering a spoonful of soothing syrup. Use a soft vector style with a pastel color palette and a caring mood."
    },
    'High Blood Pressure': {
        image: "An educational cartoon in soft pastels about high blood pressure causes. The scene shows Dr. HealthBot advising a patient. In the background, there are illustrations of causes like stress, junk food (burger, fries), and smoking, which are crossed out. A heart icon with a high-pressure gauge is visible. The mood is motivational.",
        video: "A short, 5-second animated educational video about high blood pressure. It starts with symbolic imagery of stress and junk food. It transitions to a scene of Dr. HealthBot measuring a patient's BP. The clip ends with the patient jogging happily, showing a positive lifestyle change. Use a soft vector style with a pastel color palette and an encouraging mood."
    },
    'Low Blood Pressure': {
        image: "An educational cartoon in soft pastels about low blood pressure. The scene shows a dehydrated and tired-looking person feeling dizzy. Dr. HealthBot is gently helping the patient to sit down and is offering a glass of water. The mood is supportive and gentle. Include a water droplet icon.",
        video: "A short, 5-second animated educational video about low blood pressure. It starts with a scene of a person looking tired from dehydration. It transitions to the person feeling dizzy. The clip ends with Dr. HealthBot offering a glass of water with a reassuring smile. Use a soft vector style with a pastel color palette and a caring mood."
    },
    'Irregular Pulse Rate': {
        image: "An educational cartoon in soft pastels explaining irregular pulse rate. The scene shows Dr. HealthBot explaining a heart rhythm strip (ECG) to a patient, who is wearing a smartwatch. In the background, there is a symbolic illustration of a stressed, irregular heartbeat. The mood is calm and educational.",
        video: "A short, 5-second animated educational video about irregular pulse rate. It starts with a symbolic animation of a nervous, irregular heartbeat. It transitions to a patient looking at their smartwatch with concern. The clip ends with Dr. HealthBot demonstrating slow, calming breaths. Use a soft vector style with a pastel color palette and a reassuring mood."
    },
    'Body Weight Problems': {
        image: "An educational cartoon in soft pastels about healthy body weight. The scene shows Dr. HealthBot advising a patient on a balanced lifestyle. The background includes illustrations of unhealthy habits (junk food, lack of exercise) crossed out, and healthy habits (balanced plate, walking) with checkmarks. The mood is positive and encouraging.",
        video: "A short, 5-second animated educational video about managing body weight. It starts with a scene of unhealthy habits like eating junk food and being sedentary. It transitions to Dr. HealthBot advising the patient. The clip ends with the patient happily exercising and eating a healthy salad. Use a soft vector style with a pastel color palette and a motivational mood."
    }
};


export const getBotResponse = async (chat: Chat, userInput: string): Promise<{ text: string, functionCall?: any }> => {
  try {
    const response: GenerateContentResponse = await chat.sendMessage({ message: userInput });
    const functionCalls = response.functionCalls;
    if (functionCalls && functionCalls.length > 0) {
        return { text: response.text, functionCall: functionCalls[0] };
    }
    return { text: response.text };
  } catch (error) {
    console.error("Error sending message to Gemini API:", error);
    return { text: "I'm sorry, I'm having trouble connecting right now. Please try again later." };
  }
};

export const generateImageForCondition = async (condition: string): Promise<string> => {
    const prompt = visualPrompts[condition]?.image;
    if (!prompt) {
        throw new Error("Invalid condition for image generation.");
    }
    
    try {
        const response = await ai.models.generateContent({
            model: 'gemini-2.5-flash-image',
            contents: { parts: [{ text: prompt }] },
            config: { responseModalities: [Modality.IMAGE] },
        });
        
        for (const part of response.candidates[0].content.parts) {
            if (part.inlineData) {
                const base64ImageBytes: string = part.inlineData.data;
                return `data:image/png;base64,${base64ImageBytes}`;
            }
        }
        throw new Error("No image data found in response.");

    } catch (error) {
        console.error("Error generating image:", error);
        throw new Error("Sorry, I couldn't create the image right now.");
    }
};

export const generateVideoForCondition = async (condition: string): Promise<string> => {
    const prompt = visualPrompts[condition]?.video;
    if (!prompt) {
        throw new Error("Invalid condition for video generation.");
    }

    try {
        // Create a new instance right before the call to use the latest key
        const videoAI = new GoogleGenAI({ apiKey: process.env.API_KEY });
        let operation = await videoAI.models.generateVideos({
            model: 'veo-3.1-fast-generate-preview',
            prompt: prompt,
            config: {
                numberOfVideos: 1,
                resolution: '720p',
                aspectRatio: '16:9'
            }
        });

        while (!operation.done) {
            await new Promise(resolve => setTimeout(resolve, 5000));
            operation = await videoAI.operations.getVideosOperation({ operation: operation });
        }

        const downloadLink = operation.response?.generatedVideos?.[0]?.video?.uri;
        if (!downloadLink) {
            throw new Error("Video generation completed, but no download link was found.");
        }

        const response = await fetch(`${downloadLink}&key=${process.env.API_KEY}`);
        const videoBlob = await response.blob();
        return URL.createObjectURL(videoBlob);

    } catch (error) {
        console.error("Error generating video:", error);
        if (error instanceof Error && error.message.includes("Requested entity was not found")) {
            throw new Error("Invalid API Key. Please select a project with the Veo API enabled and try again. For more info on billing, visit ai.google.dev/gemini-api/docs/billing");
        }
        throw new Error("Sorry, I couldn't create the video right now.");
    }
};


export const chatSession = model;