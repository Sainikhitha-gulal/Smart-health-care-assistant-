
export type Sender = 'user' | 'bot';

export interface Message {
  id: number;
  text: string;
  sender: Sender;
  imageUrl?: string;
  videoUrl?: string;
  visualLoading?: 'image' | 'video' | false;
  visualTriggerCondition?: string;
}
